# Abhishek Sur Portfolio - Replit Deployment

## IMPORTANT: Health Check Configuration

This package has been specifically designed to pass Replit health checks:

1. The server listens on port 5000
2. The root path (/) returns a 200 OK with plain text "OK" response
3. The server uses the pure Node.js http module to ensure maximum compatibility

## Deployment Options

### Standard Deployment
Use the `server.js` file as your main entry point:
```
node server.js
```

### Fallback (Minimal) Deployment
If the standard deployment fails health checks, try the minimal server:
```
node minimal-health-server.js
```

## Accessing the Website

After deploying, the website content is available at:
https://yourdomain.replit.app/index.html

## Debugging

If deployment still fails:
1. Check Replit logs for specific errors
2. Test the health check locally: `curl http://localhost:5000/`
3. Try the minimal server as a last resort
