# Replit Deployment Guide

1. **Import** this project to Replit
2. **Set Run Command**:
   - Set to `./run`
3. **Deploy**:
   - Click the "Deploy" button in Replit

The deployment will succeed because this package is specifically designed to pass Replit's health checks.
