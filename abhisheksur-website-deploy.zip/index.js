// Load the server
require('./server.js');
