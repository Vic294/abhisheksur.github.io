#!/bin/bash
# ULTRA-SIMPLE DEPLOYMENT SCRIPT
# This is the most minimal deployment script possible for Replit

echo "Starting Ultra-Simple Server for Replit Deployment"
echo "PORT: $PORT"

# Run the ultra-simple server directly
exec node ultra-simple-server.js