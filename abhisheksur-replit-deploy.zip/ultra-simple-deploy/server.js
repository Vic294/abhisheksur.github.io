// Compatibility redirect to ultra-simple-server
// This ensures any automated systems looking for server.js will find it

console.log('Loading compatibility server.js');
console.log('Redirecting to ultra-simple-server.js');
require('./ultra-simple-server.js');
