# Abhishek Sur Portfolio - Replit Deployment

## IMPORTANT DEPLOYMENT INSTRUCTIONS

This server is specifically optimized for Replit deployment:

1. The server MUST listen on port 3000 (not 5000) as required by Replit
2. The root path (/) MUST return a plain text "OK" response with status 200
3. Do not modify the health check handling in index.js

## How this works:

- The server first handles health checks at the root path (/)
- After passing health checks, it serves the actual website content
- To view the website, navigate to /index.html after deployment

## Testing locally:

```
node index.js
curl http://localhost:3000/   # Should return "OK"
```

## Deployment checks:

1. Verify port 3000 is used
2. Verify root path returns text/plain "OK"
3. Website content is at /index.html
