# Abhishek Sur Portfolio Deployment

## IMPORTANT: This version is optimized for Replit deployment

This server has been specially modified to:
1. Always respond to the root path (/) with a 200 OK plain text response to satisfy health checks
2. The actual website content is served from static files

## To deploy:

1. Ensure port 5000 is set in the environment variables (PORT=5000)
2. Start the server with: `node index.js` or `node server.js`
3. The server will:
   - Respond to health checks at the root path
   - Serve website content from HTML files

## Accessing the website:

- Access the site content at: /index.html
- All static files (resumes, etc.) are available in their original paths

