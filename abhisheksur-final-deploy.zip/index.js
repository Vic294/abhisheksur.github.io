const express = require('express');
const path = require('path');
const fs = require('fs');

// Create the server app
const app = express();
const PORT = process.env.PORT || 5000;

// Logging middleware for debugging
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  console.log('Headers:', JSON.stringify(req.headers, null, 2));
  next();
});

// CRITICAL: Root path for Replit health checks, must be the first route
app.get('/', (req, res) => {
  console.log('ROOT PATH ACCESSED');
  
  // Always respond with 200 OK text/plain for health checks
  res.status(200)
     .set('Content-Type', 'text/plain')
     .send('OK');
});

// Serve static files only AFTER handling the health check
app.use(express.static(__dirname));

// Print startup message
console.log(`
=======================================================
ABHISHEK SUR PORTFOLIO DEPLOYMENT SERVER
=======================================================

This server is optimized for Replit Deployment:
- The root path (/) will always return 200 OK text/plain
- Website content is served from static files
- Listening on port ${PORT}

Test the server manually with:
- curl http://localhost:${PORT}/
- Browse to http://localhost:${PORT}/index.html for content

=======================================================
`);

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});